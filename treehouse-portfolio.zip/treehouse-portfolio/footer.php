    <div class="footer-clear"></div>
<footer class="row no-max pad">           
  <p>Copyright <?php echo date('Y'); ?></p>
</footer>

  <?php wp_footer(); ?>

  </body>
</html>